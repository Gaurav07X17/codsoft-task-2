"""
TASK 2: Tic-Tac-Toe AI
An unbeatable AI opponent using the Minimax algorithm (with Alpha-Beta Pruning).
Human plays 'X', AI plays 'O'.
"""

import math

HUMAN = "X"
AI = "O"
EMPTY = " "


def print_board(board):
    print()
    for i in range(0, 9, 3):
        row = board[i:i + 3]
        print(" | ".join(row))
        if i < 6:
            print("--+---+--")
    print()


def available_moves(board):
    return [i for i, cell in enumerate(board) if cell == EMPTY]


def check_winner(board):
    """Return 'X', 'O', 'Draw', or None (game still going)."""
    win_lines = [
        (0, 1, 2), (3, 4, 5), (6, 7, 8),  # rows
        (0, 3, 6), (1, 4, 7), (2, 5, 8),  # cols
        (0, 4, 8), (2, 4, 6),             # diagonals
    ]
    for a, b, c in win_lines:
        if board[a] != EMPTY and board[a] == board[b] == board[c]:
            return board[a]

    if EMPTY not in board:
        return "Draw"

    return None


def minimax(board, depth, is_maximizing, alpha, beta):
    result = check_winner(board)
    if result == AI:
        return 10 - depth
    elif result == HUMAN:
        return depth - 10
    elif result == "Draw":
        return 0

    if is_maximizing:
        best_score = -math.inf
        for move in available_moves(board):
            board[move] = AI
            score = minimax(board, depth + 1, False, alpha, beta)
            board[move] = EMPTY
            best_score = max(best_score, score)
            alpha = max(alpha, best_score)
            if beta <= alpha:
                break
        return best_score
    else:
        best_score = math.inf
        for move in available_moves(board):
            board[move] = HUMAN
            score = minimax(board, depth + 1, True, alpha, beta)
            board[move] = EMPTY
            best_score = min(best_score, score)
            beta = min(beta, best_score)
            if beta <= alpha:
                break
        return best_score


def best_move(board):
    """Find the AI's optimal move using minimax with alpha-beta pruning."""
    best_score = -math.inf
    move_choice = None

    for move in available_moves(board):
        board[move] = AI
        score = minimax(board, 0, False, -math.inf, math.inf)
        board[move] = EMPTY

        if score > best_score:
            best_score = score
            move_choice = move

    return move_choice


def play():
    board = [EMPTY] * 9
    print("Tic-Tac-Toe: You are 'X', AI is 'O'. Positions are numbered 0-8:")
    print_board(["0", "1", "2", "3", "4", "5", "6", "7", "8"])

    while True:
        # Human turn
        result = check_winner(board)
        if result:
            break

        move = None
        while move not in available_moves(board):
            try:
                move = int(input("Your move (0-8): "))
            except ValueError:
                continue
        board[move] = HUMAN

        result = check_winner(board)
        print_board(board)
        if result:
            break

        # AI turn
        print("AI is thinking...")
        ai_move = best_move(board)
        board[ai_move] = AI
        print(f"AI played position {ai_move}")
        print_board(board)

    result = check_winner(board)
    if result == "Draw":
        print("It's a draw!")
    elif result == HUMAN:
        print("You win! (This shouldn't happen against a perfect AI 😉)")
    else:
        print("AI wins!")


if __name__ == "__main__":
    play()
