# Task 2 — Tic-Tac-Toe AI

An unbeatable Tic-Tac-Toe AI built using the **Minimax algorithm** with
**Alpha-Beta Pruning** for efficiency. The AI evaluates all possible future
game states to always make the optimal move.

## How It Works
- `minimax()` recursively simulates every possible sequence of moves.
- The AI (maximizing player) tries to maximize its score; the human
  (minimizing player) is assumed to minimize the AI's score.
- Alpha-beta pruning skips branches that can't affect the final decision,
  making the search faster.
- Winning faster is preferred (scored `10 - depth`), and losing slower is
  preferred (scored `depth - 10`), so the AI plays optimally at every stage.

## How to Run
```bash
python3 tic_tac_toe.py
```

- You play as **X**, the AI plays as **O**.
- Enter a number 0-8 to place your move (positions shown on the board grid).
- Best possible outcome against this AI is a **draw** — it cannot be beaten.

## Example
```
0 | 1 | 2
--+---+--
3 | 4 | 5
--+---+--
6 | 7 | 8

Your move (0-8): 4
AI played position 0
...
```
